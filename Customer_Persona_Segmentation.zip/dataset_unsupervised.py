

import numpy as np
import pandas as pd

RANDOM_SEED = 42
OUTPUT_FILE = "customers.csv"
N_PER_GROUP = 120  # 3 groups x 120 = 360 customers


def make_group(n, income_mean, income_sd, spend_mean, spend_sd, rng):
    """Generate one natural cluster of customers using a Gaussian blob."""
    income = rng.normal(loc=income_mean, scale=income_sd, size=n)
    spending = rng.normal(loc=spend_mean, scale=spend_sd, size=n)
    return income, spending


def generate_dataset():
    rng = np.random.default_rng(RANDOM_SEED)

    # 3 hidden natural groups (K-Means ithai thaan kandupidikkanum)
    groups = [
        # (n, income_mean(k$), income_sd, spending_mean(1-100), spending_sd)
        (N_PER_GROUP, 28.0, 7.0, 72.0, 9.0),   # low income, high spending
        (N_PER_GROUP, 58.0, 9.0, 50.0, 8.0),   # mid income, mid spending
        (N_PER_GROUP, 95.0, 12.0, 78.0, 9.0),  # high income, high spending
    ]

    incomes, spendings = [], []
    for n, im, isd, sm, ssd in groups:
        inc, spd = make_group(n, im, isd, sm, ssd, rng)
        incomes.append(inc)
        spendings.append(spd)

    annual_income_k = np.concatenate(incomes)
    spending_score = np.concatenate(spendings)

    
    annual_income_k = np.clip(annual_income_k, 12, 160).round(1)
    spending_score = np.clip(spending_score, 1, 100).round(1)

    df = pd.DataFrame({
        "customer_id": [f"CUST{i:04d}" for i in range(1, len(annual_income_k) + 1)],
        "annual_income_k": annual_income_k,
        "spending_score": spending_score,
    })

    
    df = df.sample(frac=1, random_state=RANDOM_SEED).reset_index(drop=True)
    return df


if __name__ == "__main__":
    df = generate_dataset()
    df.to_csv(OUTPUT_FILE, index=False)

    print(f"[OK] {len(df)} customer records generated -> {OUTPUT_FILE}")
    print("\nPreview:")
    print(df.head())
    print("\nSummary:")
    print(df[["annual_income_k", "spending_score"]].describe().round(2))
