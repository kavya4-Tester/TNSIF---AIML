
import joblib
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler

DATA_FILE = "customers.csv"
FEATURES = ["annual_income_k", "spending_score"]
N_CLUSTERS = 3
RANDOM_SEED = 42

MODEL_FILE = "kmeans_model.pkl"
SCALER_FILE = "scaler.pkl"
PERSONA_FILE = "persona_map.pkl"
CLUSTERED_FILE = "clustered_customers.csv"


# ------------------------------------------------------------------
# 1. Load data
# ------------------------------------------------------------------
def load_data():
    df = pd.read_csv(DATA_FILE)
    print(f"[1] Loaded {len(df)} records from {DATA_FILE}")
    return df


# ------------------------------------------------------------------
# 2. Scale features
#    Income is in 12-160 range, spending score is 1-100.
#    K-Means uses Euclidean distance -> big-range feature dominates.
#    StandardScaler => mean 0, std 1 => both features equal weight.
# ------------------------------------------------------------------
def scale_features(df):
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(df[FEATURES])
    print(f"[2] Features scaled. mean={scaler.mean_.round(2)}, scale={scaler.scale_.round(2)}")
    return scaler, X_scaled


# ------------------------------------------------------------------
# 3. Optional diagnostics: elbow (inertia) + silhouette
#    Ithu k=3 
# ------------------------------------------------------------------
def evaluate_k(X_scaled, k_range=range(2, 9)):
    print("[3] Choosing k -- inertia (elbow) + silhouette:")
    print("     k | inertia  | silhouette")
    print("    ---+----------+-----------")
    for k in k_range:
        km = KMeans(n_clusters=k, n_init=10, random_state=RANDOM_SEED)
        labels = km.fit_predict(X_scaled)
        sil = silhouette_score(X_scaled, labels)
        print(f"     {k} | {km.inertia_:8.2f} | {sil:.4f}")


# ------------------------------------------------------------------
# 4. Train the final K-Means model
# ------------------------------------------------------------------
def train_model(X_scaled):
    kmeans = KMeans(
        n_clusters=N_CLUSTERS,
        init="k-means++",     # smart centroid seeding -> better convergence
        n_init=10,            # 10 restarts, best inertia wins
        max_iter=300,
        random_state=RANDOM_SEED,
    )
    labels = kmeans.fit_predict(X_scaled)
    sil = silhouette_score(X_scaled, labels)
    print(f"[4] KMeans trained. k={N_CLUSTERS}, inertia={kmeans.inertia_:.2f}, silhouette={sil:.4f}")
    return kmeans, labels


# ------------------------------------------------------------------
# 5. Map centroids -> marketing personas
#  
# ------------------------------------------------------------------
def build_persona_map(kmeans, scaler, df, labels):
    centroids_real = scaler.inverse_transform(kmeans.cluster_centers_)

    incomes = centroids_real[:, 0]
    spendings = centroids_real[:, 1]

  
    income_cut = incomes.mean()
    spend_cut = spendings.mean()

    persona_map = {}
    for cid, (inc, spd) in enumerate(zip(incomes, spendings)):
        high_income = inc >= income_cut
        high_spend = spd >= spend_cut

        if high_income and high_spend:
            name = "Premium Loyalist"
            desc = "High earning, high spending. Your most valuable segment."
            strategy = "Early access to premium launches, loyalty tiers, concierge support."
        elif high_income and not high_spend:
            name = "Cautious Affluent"
            desc = "Money . Value-driven buyers."
            strategy = "Quality proof, warranties, comparison content, bundle savings."
        elif (not high_income) and high_spend:
            name = "Aspiring Spender"
            desc = "Modest income but spends freely. Trend and impulse driven."
            strategy = "EMI / BNPL offers, flash sales, social proof, festive campaigns."
        else:
            name = "Budget Conscious"
            desc = "Low income, low spending. Price sensitive and cautious."
            strategy = "Discount coupons, entry-level SKUs, free shipping thresholds."

        # Extra clusters (k > 4) can land in the same quadrant -- disambiguate.
        base = name
        dupes = sum(1 for p in persona_map.values() if p["persona"].startswith(base))
        if dupes:
            name = f"{base} #{dupes + 1}"

        persona_map[int(cid)] = {
            "cluster_id": int(cid),
            "persona": name,
            "description": desc,
            "strategy": strategy,
            "centroid_income_k": round(float(inc), 2),
            "centroid_spending": round(float(spd), 2),
            "size": int((labels == cid).sum()),
        }

    print("[5] Persona mapping:")
    for cid, p in persona_map.items():
        print(f"     Cluster {cid}: {p['persona']:<18} "
              f"income={p['centroid_income_k']:>6.2f}k  "
              f"spend={p['centroid_spending']:>5.2f}  n={p['size']}")

    return persona_map


# ------------------------------------------------------------------
# 6. Export artifacts
# ------------------------------------------------------------------
def export(kmeans, scaler, persona_map, df, labels):
    joblib.dump(kmeans, MODEL_FILE)
    joblib.dump(scaler, SCALER_FILE)
    joblib.dump(persona_map, PERSONA_FILE)

    out = df.copy()
    out["cluster"] = labels
    out["persona"] = [persona_map[int(c)]["persona"] for c in labels]
    out.to_csv(CLUSTERED_FILE, index=False)

    print(f"[6] Saved -> {MODEL_FILE}, {SCALER_FILE}, {PERSONA_FILE}, {CLUSTERED_FILE}")


def main():
    df = load_data()
    scaler, X_scaled = scale_features(df)
    evaluate_k(X_scaled)
    kmeans, labels = train_model(X_scaled)
    persona_map = build_persona_map(kmeans, scaler, df, labels)
    export(kmeans, scaler, persona_map, df, labels)
    print("\n[DONE] Training complete. Next: run the FastAPI backend.")


if __name__ == "__main__":
    main()
