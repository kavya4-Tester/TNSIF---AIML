

import json
import os
from datetime import datetime, timezone

import joblib
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

MODEL_FILE = "kmeans_model.pkl"
SCALER_FILE = "scaler.pkl"
PERSONA_FILE = "persona_map.pkl"
CLUSTERED_FILE = "clustered_customers.csv"
STATIC_DIR = "static"
HISTORY_FILE = "prediction_history.json"
MAX_HISTORY = 200

app = FastAPI(
    title="Customer Persona Segmenter API",
    description="Unsupervised K-Means clustering service for customer segmentation.",
    version="1.0.0",
)

# Allow the dashboard to call this API even if it's ever opened from a
# different origin (e.g. a plain file:// double-click instead of being
# served by this app).
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ------------------------------------------------------------------
# Load artifacts once at startup (not per request -> fast responses)
# ------------------------------------------------------------------
kmeans = scaler = persona_map = None
LOAD_ERROR = None

try:
    for f in (MODEL_FILE, SCALER_FILE, PERSONA_FILE):
        if not os.path.exists(f):
            raise FileNotFoundError(f)
    kmeans = joblib.load(MODEL_FILE)
    scaler = joblib.load(SCALER_FILE)
    persona_map = joblib.load(PERSONA_FILE)
    print("[API] Model artifacts loaded successfully.")
except Exception as e:  # noqa: BLE001
    LOAD_ERROR = f"Artifacts missing or corrupt ({e}). Run: python train_kmeans.py"
    print(f"[API][ERROR] {LOAD_ERROR}")

# Clustered points 
try:
    _points_df = pd.read_csv(CLUSTERED_FILE)
except Exception:  # noqa: BLE001
    _points_df = None


# ------------------------------------------------------------------
# Prediction history -- persisted to a local JSON file so past
# classifications survive a browser refresh AND a server restart.
# ------------------------------------------------------------------
def _load_history():
    if os.path.exists(HISTORY_FILE):
        try:
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:  # noqa: BLE001
            return []
    return []


def _save_history(history):
    with open(HISTORY_FILE, "w", encoding="utf-8") as f:
        json.dump(history[-MAX_HISTORY:], f, indent=2)


_history = _load_history()


# ------------------------------------------------------------------
# Schemas
# ------------------------------------------------------------------
class CustomerIn(BaseModel):
    annual_income_k: float = Field(..., ge=0, le=500, description="Annual income in thousands")
    spending_score: float = Field(..., ge=1, le=100, description="Spending score 1-100")

    model_config = {
        "json_schema_extra": {
            "examples": [{"annual_income_k": 92.0, "spending_score": 80.0}]
        }
    }


class PredictionOut(BaseModel):
    cluster_id: int
    persona: str
    description: str
    strategy: str
    centroid_income_k: float
    centroid_spending: float
    distance_to_centroid: float
    confidence: float


def _require_model():
    if kmeans is None:
        raise HTTPException(status_code=503, detail=LOAD_ERROR)


# ------------------------------------------------------------------
# Routes
# ------------------------------------------------------------------
@app.get("/")
def root():
    """Serves the dashboard if it exists, else a small JSON status page."""
    index_path = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_path):
        return FileResponse(index_path)
    return {"service": "Customer Persona Segmenter", "status": "running", "docs": "/docs"}


@app.get("/points")
def points():
    """Every clustered training point -- used to draw the background scatter."""
    _require_model()
    if _points_df is None:
        raise HTTPException(status_code=404, detail="clustered_customers.csv not found")
    return _points_df[["annual_income_k", "spending_score", "cluster", "persona"]].to_dict(orient="records")


@app.get("/health")
def health():
    return {"status": "ok" if kmeans is not None else "model_not_loaded", "detail": LOAD_ERROR}


@app.get("/clusters")
def clusters():
    """All discovered clusters with their centroids -- used by the dashboard plot."""
    _require_model()
    return {"n_clusters": len(persona_map), "clusters": list(persona_map.values())}


@app.get("/history")
def get_history():
    """Every customer classified so far, most recent first."""
    return list(reversed(_history))


@app.delete("/history")
def clear_history():
    global _history
    _history = []
    _save_history(_history)
    return {"status": "cleared"}


@app.post("/predict", response_model=PredictionOut)
def predict(customer: CustomerIn):
    """Assign an incoming customer to the nearest cluster centroid."""
    _require_model()

    
    X = pd.DataFrame(
        [[customer.annual_income_k, customer.spending_score]],
        columns=["annual_income_k", "spending_score"],
    )
    X_scaled = scaler.transform(X)

    cluster_id = int(kmeans.predict(X_scaled)[0])

    # Distance to every centroid in scaled space
    distances = np.linalg.norm(kmeans.cluster_centers_ - X_scaled[0], axis=1)
    d_own = float(distances[cluster_id])

    
    sorted_d = np.sort(distances)
    if len(sorted_d) > 1 and sorted_d[1] > 0:
        confidence = float(1 - (sorted_d[0] / sorted_d[1]))
    else:
        confidence = 1.0
    confidence = round(max(0.0, min(1.0, confidence)), 4)

    info = persona_map[cluster_id]
    result = PredictionOut(
        cluster_id=cluster_id,
        persona=info["persona"],
        description=info["description"],
        strategy=info["strategy"],
        centroid_income_k=info["centroid_income_k"],
        centroid_spending=info["centroid_spending"],
        distance_to_centroid=round(d_own, 4),
        confidence=confidence,
    )

    
    _history.append({
        "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "annual_income_k": customer.annual_income_k,
        "spending_score": customer.spending_score,
        **result.model_dump(),
    })
    _save_history(_history)

    return result
