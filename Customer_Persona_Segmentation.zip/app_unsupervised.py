

import os

import matplotlib.pyplot as plt
import pandas as pd
import requests
import seaborn as sns
import streamlit as st

API_URL = "http://localhost:8000"
CLUSTERED_FILE = "clustered_customers.csv"

st.set_page_config(page_title="Customer Persona Segmenter", page_icon="🎯", layout="wide")
sns.set_theme(style="whitegrid")

st.title("🎯 Customer Persona Segmenter")
st.caption("Unsupervised K-Means clustering • FastAPI backend • Streamlit frontend")


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------
@st.cache_data(ttl=60)
def load_clustered_data():
    if not os.path.exists(CLUSTERED_FILE):
        return None
    return pd.read_csv(CLUSTERED_FILE)


def call_api(path, method="get", payload=None):
    try:
        if method == "post":
            r = requests.post(f"{API_URL}{path}", json=payload, timeout=10)
        else:
            r = requests.get(f"{API_URL}{path}", timeout=10)
        if r.status_code != 200:
            return None, f"API returned {r.status_code}: {r.text}"
        return r.json(), None
    except requests.exceptions.ConnectionError:
        return None, "Backend not reachable"
    except Exception as e:  # noqa: BLE001
        return None, str(e)


# ------------------------------------------------------------------
# Sidebar: inputs
# ------------------------------------------------------------------
with st.sidebar:
    st.header("Customer Details")
    income = st.slider("Annual Income (in $1000s)", 10.0, 160.0, 75.0, 1.0)
    spending = st.slider("Spending Score (1-100)", 1.0, 100.0, 60.0, 1.0)
    go = st.button("Find Persona", type="primary", use_container_width=True)

    st.divider()
    health, herr = call_api("/health")
    if herr:
        st.error("Backend: offline")
    elif health.get("status") == "ok":
        st.success("Backend: online")
    else:
        st.warning(f"Backend: {health.get('detail')}")


# ------------------------------------------------------------------
# Prediction
# ------------------------------------------------------------------
result = None
if go:
    result, err = call_api(
        "/predict",
        method="post",
        payload={"annual_income_k": income, "spending_score": spending},
    )
    if err:
        st.error(err)

col_left, col_right = st.columns([1, 1.3])

with col_left:
    st.subheader("Segment Result")
    if result:
        st.metric("Persona", result["persona"])
        st.write(result["description"])
        st.info(f"**Marketing strategy:** {result['strategy']}")
        c1, c2 = st.columns(2)
        c1.metric("Cluster ID", result["cluster_id"])
        c2.metric("Confidence", f"{result['confidence'] * 100:.1f}%")
        st.caption(
            f"Centroid: income {result['centroid_income_k']}k, "
            f"spending {result['centroid_spending']} • "
            f"distance {result['distance_to_centroid']}"
        )
    else:
        st.info("Sidebar **Find Persona** click .")

# ------------------------------------------------------------------
# Scatter plot
# ------------------------------------------------------------------
with col_right:
    st.subheader("Cluster Map")
    df = load_clustered_data()

    if df is None:
        st.warning(f"{CLUSTERED_FILE}  `python train_kmeans.py`")
    else:
        fig, ax = plt.subplots(figsize=(7, 5.5))
        sns.scatterplot(
            data=df,
            x="annual_income_k",
            y="spending_score",
            hue="persona",
            palette="Set2",
            s=45,
            alpha=0.75,
            ax=ax,
        )

        # Centroids from the API
        clusters_data, cerr = call_api("/clusters")
        if clusters_data:
            for c in clusters_data["clusters"]:
                ax.scatter(
                    c["centroid_income_k"],
                    c["centroid_spending"],
                    marker="X",
                    s=260,
                    c="black",
                    edgecolors="white",
                    linewidths=1.5,
                    zorder=5,
                )

        # The new customer
        if result:
            ax.scatter(
                income, spending,
                marker="*", s=600, c="red",
                edgecolors="black", linewidths=1.2, zorder=6,
                label="New customer",
            )
            ax.annotate(
                result["persona"],
                (income, spending),
                textcoords="offset points",
                xytext=(12, 12),
                fontsize=10,
                fontweight="bold",
                color="darkred",
            )

        ax.set_xlabel("Annual Income (k$)")
        ax.set_ylabel("Spending Score")
        ax.set_title("Customer Segments (X = centroid, ★ = new customer)")
        ax.legend(loc="best", fontsize=8)
        st.pyplot(fig)

# ------------------------------------------------------------------
# Segment summary table
# ------------------------------------------------------------------
st.divider()
st.subheader("Segment Overview")
clusters_data, cerr = call_api("/clusters")
if clusters_data:
    table = pd.DataFrame(clusters_data["clusters"])[
        ["cluster_id", "persona", "centroid_income_k", "centroid_spending", "size", "strategy"]
    ]
    st.dataframe(table, use_container_width=True, hide_index=True)
else:
    st.caption("Cluster summary load backend online")
