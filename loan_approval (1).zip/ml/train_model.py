import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import joblib
import os

# Load Dataset
df = pd.read_excel("../dataset/loans.xlsx", engine="openpyxl")

# Features & Target
X = df[["income", "credit_score", "loan_amount", "employment_years"]]
y = df["loan_status"]

# Train-Test Split
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.2,
    random_state=42,
    stratify=y
)

# Train Model
model = RandomForestClassifier(
    n_estimators=100,
    random_state=42
)

model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# Accuracy
accuracy = accuracy_score(y_test, y_pred)

print("=" * 40)
print(f"Model Accuracy : {accuracy*100:.2f}%")
print("=" * 40)

# Save Model
os.makedirs("../model", exist_ok=True)

joblib.dump(model, "../model/loan_model.pkl")

print("Model saved successfully!")