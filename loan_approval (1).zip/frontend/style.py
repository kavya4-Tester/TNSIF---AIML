import streamlit as st

def load_css():

    st.markdown("""
    <style>

    /* ---------- BACKGROUND ---------- */

    .stApp{
        background: linear-gradient(135deg,#5B2C83,#7D4AC7,#B497FF);
    }

    .block-container{
        padding-top:30px;
        max-width:1200px;
    }

    /* ---------- HEADINGS ---------- */

    h1,h2,h3{
        color:#FFFFFF !important;
        text-align:center;
        font-weight:bold;
    }

    .subtitle{
        text-align:center;
        color:#F2F2F2;
        font-size:18px;
    }

    /* ---------- CARDS ---------- */

    .card{

        background:#FFFFFF;

        border-radius:18px;

        padding:20px;

        box-shadow:0px 6px 15px rgba(0,0,0,.25);

        text-align:center;

        margin-bottom:15px;
    }

    .icon{

        font-size:45px;
    }

    .title{

        color:#4B0082;

        font-size:22px;

        font-weight:bold;

        margin-top:10px;
    }

    .desc{

        color:#333333;

        font-size:15px;
    }

    /* ---------- INPUT LABEL ---------- */

    label{
        color:white !important;
        font-weight:bold !important;
    }

    /* ---------- INPUT ---------- */

    input{

        background:#ECE6FF !important;

        color:#000000 !important;

        border-radius:8px !important;
    }

    textarea{

        color:black !important;
    }

    /* ---------- BUTTON ---------- */

    div.stButton>button{

        background:#4B0082;

        color:white;

        border:none;

        border-radius:10px;

        height:45px;

        font-weight:bold;

        width:100%;
    }

    div.stButton>button:hover{

        background:#2F0057;

        color:white;
    }

    /* ---------- SUCCESS ---------- */

    .stSuccess{

        background:#D4F7D4;
    }

    /* ---------- ERROR ---------- */

    .stError{

        background:#FFDADA;
    }

    /* ---------- METRIC ---------- */

    div[data-testid="metric-container"]{

        background:white;

        border-radius:12px;

        padding:15px;

        color:black;

        box-shadow:0px 5px 10px rgba(0,0,0,.15);
    }

    </style>
    """, unsafe_allow_html=True)