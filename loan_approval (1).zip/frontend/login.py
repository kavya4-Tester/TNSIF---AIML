import streamlit as st

def login_page():

    st.title("🔐 Login")

    st.write("### Sign in to continue")

    col1, col2, col3 = st.columns([1,2,1])

    with col2:

        username = st.text_input("👤 User ID")

        password = st.text_input("🔒 Password", type="password")

        st.write("")

        if st.button("Login", use_container_width=True):

            if username == "" or password == "":
                st.error("Enter User ID and Password")

            else:
                st.session_state.user = username
                st.session_state.page = "loan"
                st.rerun()

        if st.button("⬅ Back", use_container_width=True):

            st.session_state.page = "home"
            st.rerun()