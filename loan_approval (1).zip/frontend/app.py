import streamlit as st

from style import load_css
from home import home_page
from login import login_page
from loan import loan_page
from result import result_page


# ---------------- PAGE CONFIG ----------------

st.set_page_config(
    page_title="Loan Prediction System",
    page_icon="🏦",
    layout="wide"
)


# ---------------- LOAD CSS ----------------

load_css()


# ---------------- SESSION STATE ----------------

if "page" not in st.session_state:
    st.session_state.page = "home"

if "user" not in st.session_state:
    st.session_state.user = ""

if "result" not in st.session_state:
    st.session_state.result = {}

if "loan_history" not in st.session_state:
    st.session_state.loan_history = []


# ---------------- ROUTING ----------------

if st.session_state.page == "home":

    home_page()

elif st.session_state.page == "login":

    login_page()

elif st.session_state.page == "loan":

    loan_page()

elif st.session_state.page == "result":

    result_page()