import streamlit as st
import requests

API_URL = "http://127.0.0.1:8000/predict"


def loan_page():

    st.title("🏦 Loan Application")

    col1, col2 = st.columns(2)

    with col1:

        income = st.number_input(
            "💰 Monthly Income",
            min_value=0.0,
            value=50000.0,
            step=1000.0
        )

        credit_score = st.number_input(
            "📊 Credit Score",
            min_value=300,
            max_value=900,
            value=700,
            step=1
        )

    with col2:

        loan_amount = st.number_input(
            "💵 Loan Amount",
            min_value=0.0,
            value=200000.0,
            step=1000.0
        )

        employment_years = st.number_input(
            "💼 Employment Years",
            min_value=0,
            max_value=40,
            value=5,
            step=1
        )

    st.write("")

    if st.button("🔮 Predict Loan", use_container_width=True):

        data = {
            "income": income,
            "credit_score": credit_score,
            "loan_amount": loan_amount,
            "employment_years": employment_years
        }

        try:

            response = requests.post(API_URL, json=data)

            st.write("Status Code:", response.status_code)
            st.write("Response:", response.text)

            if response.status_code == 200:

                st.session_state.result = response.json()
                st.session_state.page = "result"
                st.rerun()

            else:

                st.error(f"Prediction Failed ({response.status_code})")

        except Exception as e:

            st.error(f"Error: {e}")

    st.write("")

    if st.button("⬅ Back", use_container_width=True):

        st.session_state.page = "login"
        st.rerun()