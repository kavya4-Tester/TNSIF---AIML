import streamlit as st

def home_page():

    st.title("🏦 Loan Prediction System")

    st.write("### Smart Loan Approval using Machine Learning")

    st.write("")

    c1, c2, c3 = st.columns(3)

    with c1:
        st.info("📊 Credit Score")

    with c2:
        st.info("⚡ Fast Prediction")

    with c3:
        st.info("🔒 Secure System")

    st.write("")

    if st.button("🚀 Get Started", use_container_width=True):
        st.session_state.page = "login"
        st.rerun()