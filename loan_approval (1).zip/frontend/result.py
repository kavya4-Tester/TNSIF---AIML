import streamlit as st

def result_page():

    result = st.session_state.result

    st.title("📊 Prediction Result")

    if result["Loan_Status"] == "Approved":

        st.success("🎉 Congratulations! Your Loan is Approved.")

    else:

        st.error("❌ Sorry! Your Loan is Rejected.")

    st.write("---")

    st.subheader("Applicant Details")

    c1, c2 = st.columns(2)

    with c1:

        st.write("💰 **Monthly Income:**", result["ApplicantIncome"])

        st.write("💵 **Loan Amount:**", result["LoanAmount"])

    with c2:

        st.write("📊 **Credit Score:**", result["Credit_History"])

        st.write("💼 **Employment Years:**", result["Loan_Amount_Term"])

    st.write("---")

    c1, c2 = st.columns(2)

    with c1:

        if st.button("🔄 New Prediction", use_container_width=True):

            st.session_state.page = "loan"

            st.rerun()

    with c2:

        if st.button("🚪 Logout", use_container_width=True):

            st.session_state.page = "home"
            st.session_state.user = ""
            st.session_state.result = {}

            st.rerun()