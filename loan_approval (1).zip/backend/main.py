from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import os

app = FastAPI(title="Loan Approval Prediction API")

# Load Model
model_path = os.path.join(
    os.path.dirname(__file__),
    "..",
    "model",
    "loan_model.pkl"
)

model = joblib.load(model_path)


class LoanInput(BaseModel):
    income: float
    credit_score: int
    loan_amount: float
    employment_years: int


@app.get("/")
def home():
    return {
        "message": "Loan Approval Prediction API Running"
    }


@app.post("/predict")
def predict(data: LoanInput):

    prediction = model.predict([[
        data.income,
        data.credit_score,
        data.loan_amount,
        data.employment_years
    ]])

    status = "Approved"

    if prediction[0] == 0:
        status = "Rejected"

    return {

        "Loan_Status": status,

        "ApplicantIncome": data.income,

        "CoapplicantIncome": 0,

        "LoanAmount": data.loan_amount,

        "Loan_Amount_Term": data.employment_years,

        "Credit_History": data.credit_score,

        "Property_Area": "Urban"

    }